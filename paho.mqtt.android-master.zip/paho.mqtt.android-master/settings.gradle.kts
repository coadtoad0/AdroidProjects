rootProject.name = "MQTT-Android"

include(":serviceLibrary")
include(":extendedSample")
include(":basicSample")
