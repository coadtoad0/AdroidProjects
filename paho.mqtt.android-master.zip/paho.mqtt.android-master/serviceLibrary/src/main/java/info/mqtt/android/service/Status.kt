package info.mqtt.android.service

enum class Status {
    OK,
    ERROR
}
