package info.mqtt.android.extsample

internal object ActivityConstants {
    const val CONNECTION_KEY = "CONNECTION_KEY"
    const val CONNECTED = "CONNECTEd"
    const val historyProperty = "history"
    const val ConnectionStatusProperty = "connectionStatus"
    const val empty = ""
}
