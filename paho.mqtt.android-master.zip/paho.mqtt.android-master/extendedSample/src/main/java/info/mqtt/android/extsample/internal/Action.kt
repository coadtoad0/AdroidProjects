package info.mqtt.android.extsample.internal

enum class Action {
    CONNECT, DISCONNECT, SUBSCRIBE, PUBLISH
}
